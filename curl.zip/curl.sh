#!/bin/sh
ping png.cta-tibet.com
sleep 300 #等3秒后执行下一条
while [0]
sleep 3600
do
ping png.cta-tibet.com
done